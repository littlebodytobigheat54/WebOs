/**
 * WebOS - Server Principal
 * Node.js + Express backend com autenticação, APIs de sistema, Docker e gerenciamento de apps
 */

const express    = require('express');
const session    = require('express-session');
const bcrypt     = require('bcryptjs');
const path       = require('path');
const fs         = require('fs');
const { exec }   = require('child_process');
const si         = require('systeminformation');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Caminhos importantes ────────────────────────────────────────────────────
const DATA_DIR   = path.join(__dirname, 'data');
const APPS_DIR   = path.join(__dirname, 'apps');
const STORE_DIR  = path.join(__dirname, 'store');
const PUBLIC_DIR = path.join(__dirname, 'public');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// Garante que os diretórios existam
[DATA_DIR, APPS_DIR, STORE_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ─── Middleware global ────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'webos-super-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false,            // Colocar true se usar HTTPS
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000  // 24 horas
  }
}));

// Servir arquivos estáticos públicos (sem auth)
app.use(express.static(PUBLIC_DIR));

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Verifica se existe ao menos um usuário cadastrado */
function hasUsers() {
  if (!fs.existsSync(USERS_FILE)) return false;
  try {
    const users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
    return Array.isArray(users) && users.length > 0;
  } catch { return false; }
}

/** Lê todos os usuários do arquivo JSON */
function readUsers() {
  if (!fs.existsSync(USERS_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); }
  catch { return []; }
}

/** Salva usuários no arquivo JSON */
function saveUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

/** Sanitiza um ID de app (apenas letras, números, hífen e underscore) */
function sanitizeId(id) {
  return /^[a-zA-Z0-9_-]+$/.test(id);
}

// ─── Middleware de autenticação ───────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ error: 'Não autorizado. Faça login.' });
  }
  res.redirect('/login');
}

// ─── Arquivos de apps protegidos por auth ────────────────────────────────────
app.use('/apps', requireAuth, express.static(APPS_DIR));

// ─── Rota raiz ────────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  if (!hasUsers()) return res.redirect('/setup');
  if (!req.session.user) return res.redirect('/login');
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// ─── SETUP ────────────────────────────────────────────────────────────────────
app.get('/setup', (req, res) => {
  if (hasUsers()) return res.redirect('/login');
  res.sendFile(path.join(PUBLIC_DIR, 'setup.html'));
});

app.post('/api/setup', async (req, res) => {
  if (hasUsers()) {
    return res.status(403).json({ error: 'Setup já foi concluído' });
  }
  const { username, password, displayName } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username e senha são obrigatórios' });
  }
  if (username.length < 3 || username.length > 32) {
    return res.status(400).json({ error: 'Username deve ter entre 3 e 32 caracteres' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'Senha deve ter ao menos 6 caracteres' });
  }
  const hash  = await bcrypt.hash(password, 12);
  const users = [{
    id: 1,
    username: username.trim().toLowerCase(),
    displayName: (displayName || username).trim(),
    password: hash,
    createdAt: new Date().toISOString()
  }];
  saveUsers(users);
  res.json({ success: true, message: 'Usuário criado com sucesso!' });
});

// ─── LOGIN / LOGOUT ───────────────────────────────────────────────────────────
app.get('/login', (req, res) => {
  if (!hasUsers()) return res.redirect('/setup');
  if (req.session.user) return res.redirect('/');
  res.sendFile(path.join(PUBLIC_DIR, 'login.html'));
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username e senha são obrigatórios' });
  }
  const users = readUsers();
  const user  = users.find(u => u.username === username.trim().toLowerCase());
  if (!user) {
    return res.status(401).json({ error: 'Credenciais inválidas' });
  }
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) {
    return res.status(401).json({ error: 'Credenciais inválidas' });
  }
  req.session.user = { id: user.id, username: user.username, displayName: user.displayName };
  res.json({ success: true });
});

app.post('/api/logout', requireAuth, (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Erro ao fazer logout' });
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

// ─── API: Usuário atual ───────────────────────────────────────────────────────
app.get('/api/user', requireAuth, (req, res) => {
  res.json({ user: req.session.user });
});

// ─── API: Informações do sistema (DADOS REAIS) ───────────────────────────────
app.get('/api/system', requireAuth, async (req, res) => {
  try {
    const [cpuLoad, mem, disk, osInfo, time] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.fsSize(),
      si.osInfo(),
      si.time()
    ]);

    const primaryDisk = disk.find(d => d.mount === '/') || disk[0] || {};

    res.json({
      cpu: {
        percent: Math.round(cpuLoad.currentLoad * 10) / 10,
        cores: cpuLoad.cpus ? cpuLoad.cpus.length : 1
      },
      ram: {
        used:    mem.used,
        total:   mem.total,
        free:    mem.free,
        percent: Math.round((mem.used / mem.total) * 100)
      },
      disk: {
        used:    primaryDisk.used    || 0,
        size:    primaryDisk.size    || 0,
        free:    primaryDisk.available || 0,
        percent: Math.round(primaryDisk.use || 0)
      },
      os: {
        platform:   osInfo.platform,
        distro:     osInfo.distro,
        hostname:   osInfo.hostname,
        uptime:     time.uptime
      }
    });
  } catch (err) {
    console.error('Erro ao obter dados do sistema:', err);
    res.status(500).json({ error: 'Erro ao obter informações do sistema' });
  }
});

// ─── API: Apps instalados ─────────────────────────────────────────────────────
app.get('/api/apps', requireAuth, (req, res) => {
  if (!fs.existsSync(APPS_DIR)) return res.json([]);
  try {
    const appDirs = fs.readdirSync(APPS_DIR).filter(dir => {
      const stats = fs.statSync(path.join(APPS_DIR, dir));
      const hasFrontend = fs.existsSync(path.join(APPS_DIR, dir, 'frontend.html'));
      return stats.isDirectory() && hasFrontend;
    });

    const apps = appDirs.map(dir => {
      const metaPath = path.join(APPS_DIR, dir, 'meta.json');
      if (fs.existsSync(metaPath)) {
        try { return JSON.parse(fs.readFileSync(metaPath, 'utf8')); }
        catch {}
      }
      return { id: dir, name: dir, icon: '📦', description: '', system: false };
    });
    res.json(apps);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao listar apps' });
  }
});

// ─── API: Loja de aplicativos ─────────────────────────────────────────────────
app.get('/api/store', requireAuth, (req, res) => {
  if (!fs.existsSync(STORE_DIR)) return res.json([]);
  try {
    const storeApps = fs.readdirSync(STORE_DIR)
      .filter(f => f.endsWith('.json'))
      .map(f => {
        try {
          const appData   = JSON.parse(fs.readFileSync(path.join(STORE_DIR, f), 'utf8'));
          const installed = fs.existsSync(path.join(APPS_DIR, appData.id));
          return { ...appData, frontend: undefined, installed }; // Não expor o HTML no listing
        } catch { return null; }
      })
      .filter(Boolean);
    res.json(storeApps);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao carregar loja' });
  }
});

app.post('/api/store/install', requireAuth, (req, res) => {
  const { appId } = req.body;
  if (!appId || !sanitizeId(appId)) {
    return res.status(400).json({ error: 'ID de app inválido' });
  }
  const storeFile = path.join(STORE_DIR, `${appId}.json`);
  if (!fs.existsSync(storeFile)) {
    return res.status(404).json({ error: 'App não encontrado na loja' });
  }
  try {
    const appData = JSON.parse(fs.readFileSync(storeFile, 'utf8'));
    const appDir  = path.join(APPS_DIR, appId);
    fs.mkdirSync(appDir, { recursive: true });
    fs.writeFileSync(path.join(appDir, 'frontend.html'), appData.frontend);
    const meta = { id: appData.id, name: appData.name, icon: appData.icon,
                   description: appData.description, version: appData.version, system: false };
    fs.writeFileSync(path.join(appDir, 'meta.json'), JSON.stringify(meta, null, 2));
    res.json({ success: true, message: `${appData.name} instalado com sucesso!` });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao instalar app' });
  }
});

app.post('/api/store/uninstall', requireAuth, (req, res) => {
  const { appId } = req.body;
  if (!appId || !sanitizeId(appId)) {
    return res.status(400).json({ error: 'ID de app inválido' });
  }
  // Apps de sistema não podem ser desinstalados
  const systemApps = ['filemanager', 'terminal', 'ai-chat', 'docker-manager'];
  if (systemApps.includes(appId)) {
    return res.status(403).json({ error: 'Apps de sistema não podem ser desinstalados' });
  }
  const appDir = path.join(APPS_DIR, appId);
  if (fs.existsSync(appDir)) {
    fs.rmSync(appDir, { recursive: true, force: true });
  }
  res.json({ success: true, message: 'App desinstalado com sucesso!' });
});

// ─── API: Docker ──────────────────────────────────────────────────────────────
app.get('/api/docker/containers', requireAuth, (req, res) => {
  exec('docker ps -a --format "{{json .}}"', { timeout: 10000 }, (err, stdout, stderr) => {
    if (err) {
      const msg = (err.message || '').includes('permission denied')
        ? 'Sem permissão para usar o Docker. Adicione seu usuário ao grupo docker:\n  sudo usermod -aG docker $USER\n  newgrp docker'
        : 'Docker não disponível. Certifique-se que o Docker está instalado e rodando.';
      return res.json({ error: msg, containers: [] });
    }
    const containers = stdout.trim().split('\n')
      .filter(Boolean)
      .map(line => { try { return JSON.parse(line); } catch { return null; } })
      .filter(Boolean);
    res.json({ containers });
  });
});

app.post('/api/docker/stop', requireAuth, (req, res) => {
  const { containerId } = req.body;
  if (!containerId || !sanitizeId(containerId)) {
    return res.status(400).json({ error: 'ID de container inválido' });
  }
  exec(`docker stop ${containerId}`, { timeout: 30000 }, (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.post('/api/docker/start', requireAuth, (req, res) => {
  const { containerId } = req.body;
  if (!containerId || !sanitizeId(containerId)) {
    return res.status(400).json({ error: 'ID de container inválido' });
  }
  exec(`docker start ${containerId}`, { timeout: 30000 }, (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.post('/api/docker/remove', requireAuth, (req, res) => {
  const { containerId } = req.body;
  if (!containerId || !sanitizeId(containerId)) {
    return res.status(400).json({ error: 'ID de container inválido' });
  }
  exec(`docker rm -f ${containerId}`, { timeout: 30000 }, (err) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true });
  });
});

app.get('/api/docker/images', requireAuth, (req, res) => {
  exec('docker images --format "{{json .}}"', { timeout: 10000 }, (err, stdout) => {
    if (err) return res.json({ error: 'Docker não disponível', images: [] });
    const images = stdout.trim().split('\n')
      .filter(Boolean)
      .map(line => { try { return JSON.parse(line); } catch { return null; } })
      .filter(Boolean);
    res.json({ images });
  });
});

// ─── API: Gerenciador de Arquivos ─────────────────────────────────────────────

// Raiz permitida: impede path traversal fora do home do servidor
const FILES_ROOT = process.env.FILES_ROOT || '/';

function safePath(reqPath) {
  const normalized = path.normalize(reqPath || '/');
  // Bloqueia acesso a diretórios sensíveis
  const blocked = ['/proc', '/sys', '/dev', '/run/secrets', '/etc/shadow', '/etc/passwd'];
  if (blocked.some(b => normalized.startsWith(b))) return null;
  return normalized;
}

function formatSize(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

app.get('/api/files', requireAuth, (req, res) => {
  const target = safePath(req.query.path);
  if (!target) return res.status(403).json({ error: 'Caminho não permitido' });

  try {
    const stat = fs.statSync(target);
    if (!stat.isDirectory()) {
      return res.status(400).json({ error: 'Caminho não é um diretório' });
    }

    const entries = fs.readdirSync(target, { withFileTypes: true });
    const items = entries
      .filter(e => !e.name.startsWith('.')) // oculta dotfiles por padrão
      .map(e => {
        const fullPath = path.join(target, e.name);
        let size = 0, modified = null;
        try {
          const s = fs.statSync(fullPath);
          size     = s.size;
          modified = s.mtime.toISOString();
        } catch {}
        return {
          name:     e.name,
          path:     fullPath,
          type:     e.isDirectory() ? 'directory' : 'file',
          size,
          sizeHuman: formatSize(size),
          modified,
          ext:      e.isFile() ? path.extname(e.name).toLowerCase().slice(1) : ''
        };
      })
      .sort((a, b) => {
        // Diretórios primeiro, depois alphabético
        if (a.type !== b.type) return a.type === 'directory' ? -1 : 1;
        return a.name.localeCompare(b.name);
      });

    res.json({
      path:   target,
      parent: target !== '/' ? path.dirname(target) : null,
      items
    });
  } catch (err) {
    if (err.code === 'EACCES') return res.status(403).json({ error: 'Sem permissão para acessar este diretório' });
    if (err.code === 'ENOENT') return res.status(404).json({ error: 'Diretório não encontrado' });
    res.status(500).json({ error: err.message });
  }
});

// Leitura de arquivo de texto (para preview)
app.get('/api/files/read', requireAuth, (req, res) => {
  const target = safePath(req.query.path);
  if (!target) return res.status(403).json({ error: 'Caminho não permitido' });

  try {
    const stat = fs.statSync(target);
    if (stat.isDirectory()) return res.status(400).json({ error: 'É um diretório' });
    if (stat.size > 2 * 1024 * 1024) return res.status(413).json({ error: 'Arquivo muito grande para preview (máx 2MB)' });

    const content = fs.readFileSync(target, 'utf8');
    res.json({ path: target, content });
  } catch (err) {
    if (err.code === 'EACCES') return res.status(403).json({ error: 'Sem permissão' });
    if (err.code === 'ENOENT') return res.status(404).json({ error: 'Arquivo não encontrado' });
    res.status(500).json({ error: err.message });
  }
});

// ─── API: Terminal ────────────────────────────────────────────────────────────

// Lista de comandos permitidos no terminal web (segurança básica)
const ALLOWED_COMMANDS = new Set([
  'ls', 'pwd', 'cat', 'echo', 'whoami', 'hostname', 'uname', 'uptime',
  'df', 'du', 'free', 'ps', 'top', 'env', 'printenv', 'which', 'whereis',
  'find', 'grep', 'head', 'tail', 'wc', 'sort', 'uniq', 'cut', 'awk', 'sed',
  'tr', 'date', 'cal', 'id', 'groups', 'stat', 'file', 'lsblk', 'lscpu',
  'lsmem', 'ip', 'ifconfig', 'ping', 'traceroute', 'nslookup', 'dig',
  'curl', 'wget', 'git', 'node', 'npm', 'python3', 'pip3',
  'docker', 'docker-compose', 'systemctl', 'journalctl', 'service',
  'mkdir', 'touch', 'cp', 'mv', 'rm', 'chmod', 'chown', 'ln', 'cd',
  'tar', 'zip', 'unzip', 'gzip', 'gunzip', 'nano', 'vim', 'vi',
  'clear', 'history', 'alias', 'export', 'source', 'bash', 'sh',
  'apt', 'apt-get', 'yum', 'dnf', 'pacman', 'snap', 'flatpak',
  'tee', 'xargs', 'set', 'readlink', 'realpath', 'basename', 'dirname',
  'diff', 'patch', 'md5sum', 'sha256sum', 'kill', 'killall', 'pkill',
  'pgrep', 'nohup', 'less', 'more', 'man', 'su', 'sudo'
]);

// Padrões BLOQUEADOS explicitamente (mesmo que o primeiro token seja permitido)
const BLOCKED_PATTERNS = [
  /rm\s+-rf?\s+\/(\s|$)/,        // rm -rf /
  />\s*\/dev\/(sda|nvme|hda)/,   // sobrescrever disco
  /mkfs/,                         // formatar disco
  /dd\s+if=.*of=\/dev/,          // cópia para disco raw
  /:(){ :|:& };:/,               // fork bomb
  /shutdown|reboot|halt|poweroff/ // desligar sistema
];

app.post('/api/terminal/exec', requireAuth, (req, res) => {
  let { cmd, cwd } = req.body;

  if (!cmd || typeof cmd !== 'string') {
    return res.status(400).json({ error: 'Comando inválido' });
  }

  cmd = cmd.trim();
  if (!cmd) return res.json({ stdout: '', stderr: '', code: 0 });

  // Verifica padrões bloqueados
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(cmd)) {
      return res.status(403).json({ error: 'Comando não permitido por razões de segurança' });
    }
  }

  // Extrai o primeiro token do comando (ignora sudo no início)
  const tokens   = cmd.replace(/^sudo\s+/, '').split(/\s+/);
  const baseCmd  = tokens[0];

  if (!ALLOWED_COMMANDS.has(baseCmd)) {
    return res.status(403).json({
      error: `Comando '${baseCmd}' não está na lista de permitidos`,
      stdout: '', stderr: `bash: ${baseCmd}: comando não permitido neste terminal web`, code: 127
    });
  }

  // Valida o diretório de trabalho
  let workDir = '/';
  if (cwd && typeof cwd === 'string') {
    const safe = safePath(cwd);
    if (safe && fs.existsSync(safe)) workDir = safe;
  }

  exec(cmd, { cwd: workDir, timeout: 15000, maxBuffer: 512 * 1024 }, (err, stdout, stderr) => {
    res.json({
      stdout: stdout || '',
      stderr: stderr || '',
      code:   err ? (err.code || 1) : 0,
      cwd:    workDir
    });
  });
});

// ─── API: Docker - run (subir container por imagem) ──────────────────────────

app.post('/api/docker/run', requireAuth, (req, res) => {
  const { image, name, ports, envs, volumes, restart } = req.body;

  if (!image || typeof image !== 'string' || !/^[a-zA-Z0-9_\-:/.\[\]@]+$/.test(image)) {
    return res.status(400).json({ error: 'Nome de imagem inválido' });
  }

  let cmd = 'docker run -d';

  // Nome do container (opcional)
  if (name && /^[a-zA-Z0-9_-]+$/.test(name)) {
    cmd += ` --name ${name}`;
  }

  // Política de restart
  const validRestarts = ['no', 'always', 'unless-stopped', 'on-failure'];
  if (restart && validRestarts.includes(restart)) {
    cmd += ` --restart ${restart}`;
  }

  // Mapeamento de portas ex: ["8080:80", "443:443"]
  if (Array.isArray(ports)) {
    for (const p of ports) {
      if (/^\d{1,5}:\d{1,5}$/.test(p)) {
        cmd += ` -p ${p}`;
      }
    }
  }

  // Variáveis de ambiente ex: ["VAR=valor"]
  if (Array.isArray(envs)) {
    for (const e of envs) {
      if (/^[A-Z_][A-Z0-9_]*=.+$/i.test(e)) {
        cmd += ` -e "${e}"`;
      }
    }
  }

  // Volumes ex: ["/host/path:/container/path"]
  if (Array.isArray(volumes)) {
    for (const v of volumes) {
      if (/^[a-zA-Z0-9_/.-]+:[a-zA-Z0-9_/.-]+(:[ro|rw]{2})?$/.test(v)) {
        cmd += ` -v ${v}`;
      }
    }
  }

  cmd += ` ${image}`;

  exec(cmd, { timeout: 60000 }, (err, stdout, stderr) => {
    if (err) {
      return res.status(500).json({ error: stderr || err.message });
    }
    const containerId = stdout.trim().substring(0, 12);
    res.json({ success: true, containerId, message: `Container iniciado: ${containerId}` });
  });
});

// ─── Iniciar servidor ─────────────────────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║         WebOS - Iniciando...             ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  URL: http://0.0.0.0:${PORT}                ║`);
  console.log(`║  Compatível com ngrok e acesso remoto    ║`);
  if (!hasUsers()) {
    console.log('║  ⚠  Primeiro acesso: vá para /setup     ║');
  } else {
    console.log('║  ✓  Sistema pronto para uso              ║');
  }
  console.log('╚══════════════════════════════════════════╝\n');
});
