
/** Re-executa Lucide após injeção dinâmica de ícones */
function refreshIcons() {
  if (window.lucide) {
    try { window.lucide.createIcons(); } catch(e) {}
  }
}
/* ══════════════════════════════════════════════════════════════
   WebOS — script.js
   Window Manager • App System • System Stats • Store
   ══════════════════════════════════════════════════════════════ */

'use strict';

// ─── Estado global ────────────────────────────────────────────
const WM = {
  windows:    {},      // id → { el, appId, title, minimized }
  zCounter:   100,
  focusedId:  null,
  apps:       [],
  user:       null,
};

// ─── Utilitários ─────────────────────────────────────────────

/** Formata bytes para exibição humana */
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(1) + ' ' + sizes[i];
}

/** Formata segundos de uptime */
function formatUptime(secs) {
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

/** Gera ID único para janelas */
function uid() {
  return 'w_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
}

/** Cor da barra de progresso baseada no percentual */
function barColor(pct) {
  if (pct > 85) return '#ff4757';
  if (pct > 65) return '#ffa502';
  return null; // usar gradiente padrão
}

// ─── Sistema de notificações ────────────────────────────────

function toast(message, type = 'info', duration = 3500) {
  const icons = { success: 'check', error: 'x', info: 'info', warn: 'triangle-alert' };
  const container = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span class="toast-icon"><i data-lucide="${icons[type] || 'info'}"></i></span><span>${message}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.classList.add('removing');
    setTimeout(() => el.remove(), 200);
  }, duration);
}

// ─── Relógio ─────────────────────────────────────────────────

function updateClock() {
  const now = new Date();
  const h   = now.getHours().toString().padStart(2, '0');
  const m   = now.getMinutes().toString().padStart(2, '0');
  const el  = document.getElementById('clock');
  if (el) el.textContent = `${h}:${m}`;
}
updateClock();
setInterval(updateClock, 10000);

// ─── Saudação dinâmica ────────────────────────────────────────

function setGreeting(displayName) {
  const h  = new Date().getHours();
  const greet = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  const el = document.getElementById('homeGreeting');
  if (el) el.textContent = `${greet}, ${displayName || 'Admin'}! 👋`;
}

// ─── Carregar dados do usuário ────────────────────────────────

async function loadUser() {
  try {
    const res  = await fetch('/api/user');
    if (!res.ok) { window.location.href = '/login'; return; }
    const data = await res.json();
    WM.user    = data.user;
    const initial = (data.user.displayName || data.user.username || 'U')[0].toUpperCase();
    document.getElementById('userAvatar').textContent   = initial;
    document.getElementById('userName').textContent     = data.user.displayName || data.user.username;
    document.getElementById('dropAvatar').textContent   = initial;
    document.getElementById('dropName').textContent     = data.user.displayName || data.user.username;
    setGreeting(data.user.displayName || data.user.username);
  } catch (e) {
    window.location.href = '/login';
  }
}

// ─── Estatísticas do sistema ──────────────────────────────────

async function fetchStats() {
  try {
    const res  = await fetch('/api/system');
    if (!res.ok) return;
    const data = await res.json();

    // Top bar mini stats
    const cpuPct  = data.cpu.percent;
    const ramPct  = data.ram.percent;
    const diskPct = data.disk.percent;

    document.getElementById('cpuVal').textContent  = cpuPct  + '%';
    document.getElementById('ramVal').textContent  = ramPct  + '%';
    document.getElementById('diskVal').textContent = diskPct + '%';
    document.getElementById('cpuBar').style.width  = cpuPct  + '%';
    document.getElementById('ramBar').style.width  = ramPct  + '%';
    document.getElementById('diskBar').style.width = diskPct + '%';

    // Set bar colors based on usage
    ['cpuBar','ramBar','diskBar'].forEach((id, i) => {
      const pct = [cpuPct, ramPct, diskPct][i];
      const el  = document.getElementById(id);
      const c   = barColor(pct);
      if (c) el.style.background = c;
      else el.style.background = '';
    });

    // Info cards
    document.getElementById('cpuCard').textContent  = cpuPct + '%';
    document.getElementById('ramCard').textContent  = `${formatBytes(data.ram.used)} / ${formatBytes(data.ram.total)}`;
    document.getElementById('diskCard').textContent = `${formatBytes(data.disk.used)} / ${formatBytes(data.disk.size)}`;
    document.getElementById('cpuCardBar').style.width  = cpuPct  + '%';
    document.getElementById('ramCardBar').style.width  = ramPct  + '%';
    document.getElementById('diskCardBar').style.width = diskPct + '%';

    // OS info
    if (data.os) {
      document.getElementById('osCard').textContent   = data.os.distro || data.os.platform || '--';
      document.getElementById('hostCard').textContent = `${data.os.hostname} · Up ${formatUptime(data.os.uptime)}`;
    }
  } catch (e) { /* silently fail */ }
}

fetchStats();
setInterval(fetchStats, 5000);

// ─── Gerenciador de Apps ──────────────────────────────────────

async function loadApps() {
  try {
    const res   = await fetch('/api/apps');
    const apps  = await res.json();
    WM.apps     = apps;
    renderAppGrid(apps);
    renderTaskbar(apps);
  } catch (e) {
    toast('Erro ao carregar apps', 'error');
  }
}

function renderAppGrid(apps) {
  const grid = document.getElementById('appGrid');
  grid.innerHTML = '';
  if (!apps || apps.length === 0) {
    grid.innerHTML = '<p style="color:var(--text-muted);font-size:.85rem;grid-column:1/-1;padding:.5rem 0">Nenhum app instalado. Visite a Loja!</p>';
    return;
  }
  apps.forEach((app, i) => {
    const el = document.createElement('div');
    el.className  = 'app-icon';
    el.role       = 'listitem';
    el.tabIndex   = 0;
    el.setAttribute('aria-label', `Abrir ${app.name}`);
    el.style.animationDelay = (i * 0.05) + 's';
    el.innerHTML  = `
      ${app.system ? '<div class="app-icon-system-badge" title="App do sistema"></div>' : ''}
      <span class="app-icon-emoji"><i data-lucide="${app.icon || 'package'}"></i></span>
      <span class="app-icon-name">${app.name}</span>
    `;
    el.addEventListener('click', () => openApp(app));
    el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openApp(app); } });
    el.addEventListener('contextmenu', e => { e.preventDefault(); showAppContextMenu(e, app); });
    grid.appendChild(el);
  });
}

function renderTaskbar(apps) {
  const bar = document.getElementById('taskbarApps');
  bar.innerHTML = '';
  // Só mostra apps abertos na taskbar (gerenciado pelo WM)
}

// ─── Gerenciador de Janelas ───────────────────────────────────

function openApp(app) {
  // Se já tem janela aberta para este app, focar nela
  const existingId = Object.keys(WM.windows).find(id => WM.windows[id].appId === app.id);
  if (existingId) {
    focusWindow(existingId);
    const win = WM.windows[existingId];
    if (win.minimized) restoreWindow(existingId);
    return;
  }

  const id = uid();
  const isMobile = window.innerWidth < 768;
  const layer = document.getElementById('windowsLayer');
  const layerRect = layer.getBoundingClientRect();

  // Posição inicial aleatória dentro da área disponível
  const margin = 40;
  const maxX = Math.max(margin, layerRect.width - 680 - margin);
  const maxY = Math.max(margin, layerRect.height - 480 - margin);
  const startX = isMobile ? 0 : Math.floor(Math.random() * Math.min(maxX, 200)) + 30;
  const startY = isMobile ? 0 : Math.floor(Math.random() * Math.min(maxY, 120)) + 20;
  const width  = isMobile ? '100%' : Math.min(720, layerRect.width - margin * 2) + 'px';
  const height = isMobile ? '100%' : Math.min(520, layerRect.height - margin * 2) + 'px';

  const el = document.createElement('div');
  el.className = 'window opening';
  el.id = id;
  el.style.cssText = `
    left: ${isMobile ? '0' : startX + 'px'};
    top: ${isMobile ? '0' : startY + 'px'};
    width: ${width}; height: ${height};
    z-index: ${++WM.zCounter};
  `;

  el.innerHTML = `
    <div class="win-titlebar" data-winid="${id}">
      <div class="win-titlebar-left">
        <span class="win-titlebar-icon"><i data-lucide="${app.icon || 'package'}"></i></span>
        <span class="win-titlebar-title">${app.name}</span>
      </div>
      <div class="win-controls">
        <button class="win-btn win-btn-minimize" onclick="minimizeWindow('${id}')" title="Minimizar" aria-label="Minimizar"></button>
        <button class="win-btn win-btn-maximize" onclick="toggleMaximize('${id}')" title="Maximizar" aria-label="Maximizar"></button>
        <button class="win-btn win-btn-close" onclick="closeWindow('${id}')" title="Fechar" aria-label="Fechar"></button>
      </div>
    </div>
    <div class="win-content">
      <iframe src="/apps/${app.id}/frontend.html"
              title="${app.name}"
              sandbox="allow-scripts allow-forms allow-same-origin allow-popups"
              loading="lazy"
              allowfullscreen></iframe>
    </div>
    <div class="win-resize-handle" data-winid="${id}" title="Redimensionar"></div>
  `;

  layer.appendChild(el);
  WM.windows[id] = { el, appId: app.id, app, minimized: false, maximized: false,
                     originalStyle: null };

  // Remover classe de animação após animar
  setTimeout(() => el.classList.remove('opening'), 300);

  focusWindow(id);
  addToTaskbar(id, app);
  makeDraggable(el, id);
  makeResizable(el, id);
}

function focusWindow(id) {
  if (WM.focusedId === id) return;
  // Remover foco anterior
  if (WM.focusedId && WM.windows[WM.focusedId]) {
    WM.windows[WM.focusedId].el.classList.remove('focused');
  }
  const win = WM.windows[id];
  if (!win) return;
  WM.focusedId = id;
  win.el.style.zIndex = ++WM.zCounter;
  win.el.classList.add('focused');
  updateTaskbar();
}

function closeWindow(id) {
  const win = WM.windows[id];
  if (!win) return;
  win.el.classList.add('closing');
  setTimeout(() => {
    win.el.remove();
    delete WM.windows[id];
    removeFromTaskbar(id);
    if (WM.focusedId === id) {
      WM.focusedId = null;
      // Focar na janela mais recente
      const ids = Object.keys(WM.windows);
      if (ids.length) focusWindow(ids[ids.length - 1]);
    }
  }, 200);
}

function minimizeWindow(id) {
  const win = WM.windows[id];
  if (!win) return;
  win.minimized = true;
  win.el.classList.add('minimized');
  if (WM.focusedId === id) WM.focusedId = null;
  updateTaskbar();
}

function restoreWindow(id) {
  const win = WM.windows[id];
  if (!win) return;
  win.minimized = false;
  win.el.classList.remove('minimized');
  focusWindow(id);
}

function toggleMaximize(id) {
  const win = WM.windows[id];
  if (!win) return;
  if (win.maximized) {
    // Restaurar
    win.el.style.cssText = win.originalStyle;
    win.maximized = false;
  } else {
    // Salvar estilo original e maximizar
    win.originalStyle = win.el.style.cssText;
    win.el.style.cssText = `left:0;top:0;width:100%;height:100%;z-index:${win.el.style.zIndex};`;
    win.maximized = true;
  }
}

// ─── Taskbar dinâmica ─────────────────────────────────────────

function addToTaskbar(id, app) {
  const bar = document.getElementById('taskbarApps');
  const el  = document.createElement('div');
  el.className  = 'taskbar-item active';
  el.id         = 'tb_' + id;
  el.title      = app.name;
  el.tabIndex   = 0;
  el.innerHTML  = `
    <span class="taskbar-item-icon"><i data-lucide="${app.icon || 'package'}"></i></span>
    <span class="taskbar-item-label">${app.name}</span>
  `;
  el.addEventListener('click', () => {
    const win = WM.windows[id];
    if (!win) return;
    if (win.minimized) { restoreWindow(id); }
    else if (WM.focusedId === id) { minimizeWindow(id); }
    else { focusWindow(id); }
  });
  el.addEventListener('keydown', e => { if (e.key === 'Enter') el.click(); });
  bar.appendChild(el);
}

function removeFromTaskbar(id) {
  const el = document.getElementById('tb_' + id);
  if (el) el.remove();
}

function updateTaskbar() {
  Object.keys(WM.windows).forEach(id => {
    const el = document.getElementById('tb_' + id);
    if (!el) return;
    const win = WM.windows[id];
    el.classList.toggle('active', id === WM.focusedId && !win.minimized);
  });
}

// ─── Drag & Drop de janelas ───────────────────────────────────

function makeDraggable(windowEl, id) {
  const titlebar = windowEl.querySelector('.win-titlebar');
  let dragging = false, startX, startY, origLeft, origTop;

  function onStart(e) {
    if (e.target.closest('.win-controls')) return;
    const win = WM.windows[id];
    if (win && win.maximized) return;
    dragging = true;
    focusWindow(id);
    const point = e.touches ? e.touches[0] : e;
    startX   = point.clientX;
    startY   = point.clientY;
    origLeft = windowEl.offsetLeft;
    origTop  = windowEl.offsetTop;
    windowEl.style.transition = 'none';
    e.preventDefault();
  }

  function onMove(e) {
    if (!dragging) return;
    const point = e.touches ? e.touches[0] : e;
    const dx = point.clientX - startX;
    const dy = point.clientY - startY;
    const layer = document.getElementById('windowsLayer');
    const maxX = layer.clientWidth  - windowEl.offsetWidth;
    const maxY = layer.clientHeight - windowEl.offsetHeight;
    windowEl.style.left = Math.max(0, Math.min(maxX, origLeft + dx)) + 'px';
    windowEl.style.top  = Math.max(0, Math.min(maxY, origTop  + dy)) + 'px';
  }

  function onEnd() {
    dragging = false;
    windowEl.style.transition = '';
  }

  titlebar.addEventListener('mousedown',  onStart);
  titlebar.addEventListener('touchstart', onStart, { passive: false });
  document.addEventListener('mousemove',  onMove);
  document.addEventListener('touchmove',  onMove, { passive: false });
  document.addEventListener('mouseup',    onEnd);
  document.addEventListener('touchend',   onEnd);

  // Clique na janela foca ela
  windowEl.addEventListener('mousedown', () => focusWindow(id));
  windowEl.addEventListener('touchstart', () => focusWindow(id), { passive: true });
}

// ─── Resize de janelas ────────────────────────────────────────

function makeResizable(windowEl, id) {
  const handle = windowEl.querySelector('.win-resize-handle');
  if (!handle) return;
  let resizing = false, startX, startY, startW, startH;

  handle.addEventListener('mousedown', e => {
    resizing = true;
    startX   = e.clientX; startY = e.clientY;
    startW   = windowEl.offsetWidth; startH = windowEl.offsetHeight;
    e.preventDefault();
    e.stopPropagation();
  });

  document.addEventListener('mousemove', e => {
    if (!resizing) return;
    const w = Math.max(320, startW + e.clientX - startX);
    const h = Math.max(240, startH + e.clientY - startY);
    windowEl.style.width  = w + 'px';
    windowEl.style.height = h + 'px';
  });

  document.addEventListener('mouseup', () => { resizing = false; });
}

// ─── Context Menu do App ──────────────────────────────────────

function showAppContextMenu(e, app) {
  const menu = document.getElementById('contextMenu');
  const items = [];

  items.push(`<div class="ctx-item" onclick="openApp(${JSON.stringify(app).replace(/"/g,'&quot;')});closeContextMenu()">▶ Abrir</div>`);

  // Verificar se está instalado via loja (não é app de sistema)
  const systemApps = ['filemanager','terminal','ai-chat','docker-manager'];
  if (!systemApps.includes(app.id)) {
    items.push('<div class="ctx-divider"></div>');
    items.push(`<div class="ctx-item danger" onclick="confirmUninstall('${app.id}','${app.name}');closeContextMenu()"><i data-lucide="trash-2"></i> Desinstalar</div>`);
  }

  menu.innerHTML = items.join('');
  menu.style.left = Math.min(e.clientX, window.innerWidth  - 200) + 'px';
  menu.style.top  = Math.min(e.clientY, window.innerHeight - 100) + 'px';
  menu.classList.add('open');
  menu.removeAttribute('aria-hidden');
}

function closeContextMenu() {
  const menu = document.getElementById('contextMenu');
  menu.classList.remove('open');
  menu.setAttribute('aria-hidden', 'true');
}

document.addEventListener('click', closeContextMenu);

// ─── Loja de Aplicativos ──────────────────────────────────────

let storeApps = [];

async function openStore() {
  const overlay = document.getElementById('storeOverlay');
  overlay.classList.add('open');
  overlay.removeAttribute('aria-hidden');
  await loadStore();
}

function closeStore() {
  const overlay = document.getElementById('storeOverlay');
  overlay.classList.remove('open');
  overlay.setAttribute('aria-hidden', 'true');
}

// Fechar loja ao clicar fora
document.getElementById('storeOverlay').addEventListener('click', function(e) {
  if (e.target === this) closeStore();
});

async function loadStore() {
  const grid = document.getElementById('storeGrid');
  grid.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:2rem;grid-column:1/-1">Carregando...</p>';
  try {
    const res  = await fetch('/api/store');
    storeApps  = await res.json();
    renderStore(storeApps);
  } catch (e) {
    grid.innerHTML = '<p style="color:var(--danger);text-align:center;padding:2rem;grid-column:1/-1">Erro ao carregar loja</p>';
  }
}

function renderStore(apps) {
  const grid  = document.getElementById('storeGrid');
  const query = document.getElementById('storeSearch').value.toLowerCase().trim();
  const filtered = query ? apps.filter(a =>
    a.name.toLowerCase().includes(query) || (a.description||'').toLowerCase().includes(query)
  ) : apps;

  if (!filtered.length) {
    grid.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:2rem;grid-column:1/-1">Nenhum app encontrado</p>';
    return;
  }

  const systemApps = ['filemanager','terminal','ai-chat','docker-manager'];

  grid.innerHTML = filtered.map(app => {
    const isSystem   = systemApps.includes(app.id);
    const installed  = app.installed;
    let actions = '';
    if (isSystem) {
      actions = '<span class="badge-system">Sistema</span>';
    } else if (installed) {
      actions = `
        <span class="badge-installed">✓ Instalado</span>
        <button class="btn-open" onclick="openAppById('${app.id}')">Abrir</button>
        <button class="btn-uninstall" onclick="uninstallApp('${app.id}','${app.name}')">Remover</button>
      `;
    } else {
      actions = `<button class="btn-install" onclick="installApp('${app.id}','${app.name}')">⬇ Instalar</button>`;
    }

    return `
      <div class="store-app-card" id="store-card-${app.id}">
        <div class="store-app-icon"><i data-lucide="${app.icon || 'package'}"></i></div>
        <div class="store-app-info">
          <div class="store-app-name">${app.name}</div>
          <div class="store-app-desc">${app.description || ''}</div>
          <div class="store-app-meta">v${app.version || '1.0.0'} · ${app.category || 'Geral'}</div>
          <div class="store-app-actions">${actions}</div>
        </div>
      </div>
    `;
  }).join('');
}

// Busca na loja
document.getElementById('storeSearch').addEventListener('input', () => renderStore(storeApps));

async function installApp(appId, appName) {
  const card = document.getElementById(`store-card-${appId}`);
  const btn  = card && card.querySelector('.btn-install');
  if (btn) { btn.disabled = true; btn.textContent = 'Instalando...'; }

  try {
    const res  = await fetch('/api/store/install', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId })
    });
    const data = await res.json();
    if (data.success) {
      toast(`${appName} instalado!`, 'success');
      await loadStore();      // Recarregar loja
      await loadApps();       // Recarregar grid de apps
    } else {
      toast(data.error || 'Erro ao instalar', 'error');
      if (btn) { btn.disabled = false; btn.textContent = '⬇ Instalar'; }
    }
  } catch (e) {
    toast('Erro de conexão', 'error');
    if (btn) { btn.disabled = false; btn.textContent = '⬇ Instalar'; }
  }
}

async function uninstallApp(appId, appName) {
  if (!confirm(`Desinstalar "${appName}"?`)) return;
  try {
    const res  = await fetch('/api/store/uninstall', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ appId })
    });
    const data = await res.json();
    if (data.success) {
      toast(`${appName} removido`, 'info');
      // Fechar janela se estiver aberta
      Object.keys(WM.windows).forEach(id => {
        if (WM.windows[id].appId === appId) closeWindow(id);
      });
      await loadStore();
      await loadApps();
    } else {
      toast(data.error || 'Erro ao remover', 'error');
    }
  } catch (e) {
    toast('Erro de conexão', 'error');
  }
}

function confirmUninstall(appId, appName) {
  const app = WM.apps.find(a => a.id === appId);
  if (app) uninstallApp(appId, appName);
}

function openAppById(appId) {
  const app = WM.apps.find(a => a.id === appId);
  if (app) { openApp(app); closeStore(); }
}

// ─── User Menu ────────────────────────────────────────────────

document.getElementById('userMenuBtn').addEventListener('click', function(e) {
  e.stopPropagation();
  const menu = document.getElementById('userMenu');
  menu.classList.toggle('open');
  menu.setAttribute('aria-hidden', !menu.classList.contains('open'));
});

document.addEventListener('click', function(e) {
  const menu = document.getElementById('userMenu');
  if (!e.target.closest('#userMenuBtn') && !e.target.closest('#userMenu')) {
    menu.classList.remove('open');
    menu.setAttribute('aria-hidden', 'true');
  }
});

async function doLogout() {
  try {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login';
  } catch { window.location.href = '/login'; }
}

// ─── Botão de Apps (toggle home screen) ──────────────────────

document.getElementById('appsToggle').addEventListener('click', function() {
  const home = document.getElementById('homeScreen');
  home.style.display = home.style.display === 'none' ? '' : '';
  // Scroll to top
  document.getElementById('desktop').scrollTop = 0;
});

// ─── About / Settings ────────────────────────────────────────

function openAbout() {
  document.getElementById('userMenu').classList.remove('open');
  // Criar janela de "Sobre"
  const aboutApp = {
    id:   '_about',
    name: 'Sobre o WebOS',
    icon: 'info',
  };
  const existingId = Object.keys(WM.windows).find(id => WM.windows[id].appId === '_about');
  if (existingId) { focusWindow(existingId); return; }

  const id = uid();
  const layer = document.getElementById('windowsLayer');
  const el = document.createElement('div');
  el.className = 'window opening';
  el.id = id;
  el.style.cssText = `left:50%;top:50%;transform:translate(-50%,-50%);width:420px;height:340px;z-index:${++WM.zCounter};`;
  el.innerHTML = `
    <div class="win-titlebar" data-winid="${id}">
      <div class="win-titlebar-left">
        <span class="win-titlebar-icon"><i data-lucide="info"></i></span>
        <span class="win-titlebar-title">Sobre o WebOS</span>
      </div>
      <div class="win-controls">
        <button class="win-btn win-btn-close" onclick="closeWindow('${id}')" aria-label="Fechar"></button>
      </div>
    </div>
    <div class="win-content" style="padding:2rem;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:.75rem;pointer-events:all;overflow:auto;">
      <div style="font-size:3rem">🌐</div>
      <h2 style="font-size:1.4rem;background:linear-gradient(135deg,#fff,#a0b4ff);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent">WebOS</h2>
      <p style="color:var(--text-muted);font-size:.85rem;line-height:1.6;max-width:300px">
        Sistema operacional web inspirado em Umbrel OS e CasaOS.<br>
        Construído com Node.js + Express + JavaScript puro.
      </p>
      <div style="display:flex;gap:.5rem;flex-wrap:wrap;justify-content:center;margin-top:.5rem">
        <span style="background:var(--glass);border:1px solid var(--border);padding:.3rem .7rem;border-radius:20px;font-size:.75rem;color:var(--text-muted)">Node.js</span>
        <span style="background:var(--glass);border:1px solid var(--border);padding:.3rem .7rem;border-radius:20px;font-size:.75rem;color:var(--text-muted)">Express</span>
        <span style="background:var(--glass);border:1px solid var(--border);padding:.3rem .7rem;border-radius:20px;font-size:.75rem;color:var(--text-muted)">Glassmorphism</span>
        <span style="background:var(--glass);border:1px solid var(--border);padding:.3rem .7rem;border-radius:20px;font-size:.75rem;color:var(--text-muted)">v1.0.0</span>
      </div>
    </div>
  `;
  layer.appendChild(el);
  WM.windows[id] = { el, appId: '_about', app: aboutApp, minimized: false, maximized: false };
  setTimeout(() => el.classList.remove('opening'), 300);
  focusWindow(id);
  addToTaskbar(id, aboutApp);
  makeDraggable(el, id);
}

// openSettings() defined in settings section below

// ─── Partículas no wallpaper ──────────────────────────────────

function createParticles() {
  const container = document.getElementById('particles');
  if (!container) return;
  for (let i = 0; i < 20; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    const size = Math.random() * 2 + 1;
    p.style.cssText = `
      left: ${Math.random() * 100}%;
      bottom: -${size}px;
      width: ${size}px;
      height: ${size}px;
      animation-duration: ${Math.random() * 15 + 10}s;
      animation-delay: ${Math.random() * 10}s;
      opacity: ${Math.random() * 0.5 + 0.1};
    `;
    container.appendChild(p);
  }
}
createParticles();

// ─── Teclado global ───────────────────────────────────────────

document.addEventListener('keydown', function(e) {
  // Esc fecha menu / loja
  if (e.key === 'Escape') {
    closeContextMenu();
    if (document.getElementById('storeOverlay').classList.contains('open')) {
      closeStore(); return;
    }
    document.getElementById('userMenu').classList.remove('open');
  }
  // Alt+F4 fecha janela focada
  if (e.altKey && e.key === 'F4' && WM.focusedId) {
    e.preventDefault();
    closeWindow(WM.focusedId);
  }
});

// ─── Inicialização ────────────────────────────────────────────

async function init() {
  await loadUser();
  await loadApps();
  loadSettingsState();   // Restaura wallpaper, tema, foto de perfil
}

init();


/* ══════════════════════════════════════════════════════════════
   SETTINGS — Wallpaper, Perfil, Aparência, Sistema
   ══════════════════════════════════════════════════════════════ */

// ─── Presets de wallpaper ──────────────────────────────────────
const WP_PRESETS = [
  {
    id: 'default',
    label: 'Padrão',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 80% 60% at 15% 20%, rgba(79,124,255,0.12) 0%, transparent 60%),
      radial-gradient(ellipse 60% 50% at 85% 75%, rgba(6,214,160,0.08) 0%, transparent 55%),
      radial-gradient(ellipse 50% 40% at 50% 100%, rgba(255,107,157,0.05) 0%, transparent 50%),
      linear-gradient(160deg, #040912 0%, #060c1a 40%, #050a14 100%)`
  },
  {
    id: 'aurora',
    label: 'Aurora',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 90% 70% at 10% 10%, rgba(6,214,160,0.25) 0%, transparent 55%),
      radial-gradient(ellipse 70% 60% at 90% 80%, rgba(79,124,255,0.2) 0%, transparent 50%),
      radial-gradient(ellipse 60% 50% at 50% 50%, rgba(255,107,157,0.1) 0%, transparent 55%),
      linear-gradient(160deg, #020d0a 0%, #050d15 50%, #040912 100%)`
  },
  {
    id: 'sunset',
    label: 'Pôr do Sol',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 100% 70% at 50% 0%, rgba(255,107,157,0.35) 0%, transparent 50%),
      radial-gradient(ellipse 80% 60% at 20% 100%, rgba(255,165,0,0.2) 0%, transparent 55%),
      radial-gradient(ellipse 60% 50% at 80% 90%, rgba(255,71,87,0.15) 0%, transparent 50%),
      linear-gradient(180deg, #120408 0%, #1a0810 50%, #0d0508 100%)`
  },
  {
    id: 'ocean',
    label: 'Oceano',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 80% 60% at 50% 0%, rgba(0,180,255,0.2) 0%, transparent 60%),
      radial-gradient(ellipse 60% 50% at 10% 80%, rgba(0,100,200,0.15) 0%, transparent 55%),
      radial-gradient(ellipse 70% 40% at 90% 50%, rgba(6,214,160,0.12) 0%, transparent 50%),
      linear-gradient(180deg, #020810 0%, #030d1a 50%, #020a12 100%)`
  },
  {
    id: 'forest',
    label: 'Floresta',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 80% 60% at 30% 20%, rgba(34,197,94,0.15) 0%, transparent 60%),
      radial-gradient(ellipse 60% 50% at 70% 80%, rgba(16,185,129,0.12) 0%, transparent 55%),
      radial-gradient(ellipse 50% 40% at 50% 50%, rgba(6,214,160,0.08) 0%, transparent 50%),
      linear-gradient(160deg, #020a04 0%, #04100a 50%, #030c06 100%)`
  },
  {
    id: 'violet',
    label: 'Violeta',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 80% 60% at 20% 20%, rgba(167,139,250,0.25) 0%, transparent 60%),
      radial-gradient(ellipse 60% 50% at 80% 70%, rgba(139,92,246,0.2) 0%, transparent 55%),
      radial-gradient(ellipse 50% 40% at 50% 100%, rgba(236,72,153,0.12) 0%, transparent 50%),
      linear-gradient(160deg, #070410 0%, #0d0618 50%, #080412 100%)`
  },
  {
    id: 'midnight',
    label: 'Meia-noite',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 60% 40% at 50% 50%, rgba(30,30,60,0.8) 0%, transparent 70%),
      linear-gradient(160deg, #010103 0%, #020206 50%, #010104 100%)`
  },
  {
    id: 'cyberpunk',
    label: 'Cyberpunk',
    type: 'gradient',
    css: `
      radial-gradient(ellipse 70% 50% at 0% 50%, rgba(255,0,128,0.2) 0%, transparent 55%),
      radial-gradient(ellipse 70% 50% at 100% 50%, rgba(0,255,200,0.15) 0%, transparent 55%),
      radial-gradient(ellipse 50% 30% at 50% 0%, rgba(255,200,0,0.08) 0%, transparent 50%),
      linear-gradient(160deg, #0a0005 0%, #040012 50%, #000a0a 100%)`
  },
];

// ─── Temas de cor ──────────────────────────────────────────────
const COLOR_THEMES = [
  { id: 'blue',    label: 'Azul (padrão)', accent: '#4f7cff', accent2: '#06d6a0', bg: '#040912' },
  { id: 'teal',    label: 'Teal',          accent: '#06d6a0', accent2: '#4f7cff', bg: '#020d0a' },
  { id: 'pink',    label: 'Rosa',          accent: '#ff6b9d', accent2: '#facc15', bg: '#0d0408' },
  { id: 'amber',   label: 'Âmbar',         accent: '#f59e0b', accent2: '#ef4444', bg: '#0a0600' },
  { id: 'purple',  label: 'Roxo',          accent: '#a78bfa', accent2: '#f472b6', bg: '#070412' },
  { id: 'mono',    label: 'Monocromático', accent: '#94a3b8', accent2: '#cbd5e1', bg: '#050507' },
];

// ─── Abrir / fechar settings ──────────────────────────────────
function openSettings() {
  document.getElementById('userMenu').classList.remove('open');
  const overlay = document.getElementById('settingsOverlay');
  overlay.classList.add('open');
  overlay.setAttribute('aria-hidden', 'false');
  settingsTab('wallpaper', overlay.querySelector('.settings-tab'));
  buildWallpaperPresets();
  buildThemePresets();
  loadProfileIntoSettings();
  loadSystemInfo();
  loadSettingsState();
}

function closeSettings() {
  const overlay = document.getElementById('settingsOverlay');
  overlay.classList.remove('open');
  overlay.setAttribute('aria-hidden', 'true');
}

document.getElementById('settingsOverlay').addEventListener('click', function(e) {
  if (e.target === this) closeSettings();
});

// ─── Troca de aba ─────────────────────────────────────────────
function settingsTab(id, btn) {
  document.querySelectorAll('.settings-pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('pane-' + id).classList.add('active');
  if (btn) btn.classList.add('active');
  if (id === 'system') loadSystemInfo();
}

// ─── Persistência (localStorage) ─────────────────────────────
function saveSettings(key, val) {
  try { localStorage.setItem('webos_settings_' + key, JSON.stringify(val)); } catch {}
}
function loadSetting(key, def) {
  try { const v = localStorage.getItem('webos_settings_' + key); return v !== null ? JSON.parse(v) : def; }
  catch { return def; }
}

// ─── WALLPAPER ────────────────────────────────────────────────

function buildWallpaperPresets() {
  const grid = document.getElementById('wallpaperPresets');
  const current = loadSetting('wallpaper_id', 'default');
  grid.innerHTML = WP_PRESETS.map(p => {
    const preview = buildWpPreviewStyle(p);
    return `<div class="wp-preset${p.id === current ? ' selected' : ''}"
                 style="${preview}"
                 onclick="applyWallpaperPreset('${p.id}')"
                 title="${p.label}">
              <div class="wp-preset-label">${p.label}</div>
            </div>`;
  }).join('');
}

function buildWpPreviewStyle(p) {
  if (p.type === 'gradient') return `background: ${p.css.replace(/\n/g,'').replace(/\s+/g,' ')};`;
  if (p.type === 'image') return `background: url('${p.url}') center/cover;`;
  return '';
}

function applyWallpaperPreset(id) {
  const preset = WP_PRESETS.find(p => p.id === id);
  if (!preset) return;
  const wpDiv = document.querySelector('#wallpaper .wp-gradient');
  if (preset.type === 'gradient') {
    wpDiv.style.background = preset.css;
    wpDiv.style.backgroundImage = '';
  }
  // Limpa imagem custom
  wpDiv.style.backgroundImage = preset.type === 'gradient' ? '' : `url('${preset.url}')`;

  saveSettings('wallpaper_id', id);
  saveSettings('wallpaper_custom', null);
  document.querySelectorAll('.wp-preset').forEach(el => el.classList.remove('selected'));
  const els = document.querySelectorAll('.wp-preset');
  WP_PRESETS.forEach((p, i) => { if (p.id === id) els[i]?.classList.add('selected'); });
  toast('Wallpaper aplicado!', 'success', 1800);
}

function applyWallpaperFile(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const url = e.target.result;
    _setWallpaperImage(url);
    saveSettings('wallpaper_custom', url);
    saveSettings('wallpaper_id', 'custom');
    toast('Wallpaper aplicado!', 'success', 1800);
  };
  reader.readAsDataURL(file);
}

function applyWallpaperUrl() {
  const url = document.getElementById('wallpaperUrl').value.trim();
  if (!url) return;
  _setWallpaperImage(url);
  saveSettings('wallpaper_custom', url);
  saveSettings('wallpaper_id', 'custom');
  toast('Wallpaper aplicado!', 'success', 1800);
}

function _setWallpaperImage(url) {
  const wpDiv = document.querySelector('#wallpaper .wp-gradient');
  wpDiv.style.background = 'none';
  wpDiv.style.backgroundImage = `url('${url}')`;
  const fit = loadSetting('wallpaper_fit', 'cover');
  _applyFit(wpDiv, fit);
  document.querySelectorAll('.wp-preset').forEach(el => el.classList.remove('selected'));
}

function applyWallpaperFit(val) {
  const wpDiv = document.querySelector('#wallpaper .wp-gradient');
  _applyFit(wpDiv, val);
  saveSettings('wallpaper_fit', val);
}

function _applyFit(el, fit) {
  const map = {
    cover: 'center/cover no-repeat',
    contain: 'center/contain no-repeat',
    center: 'center/auto no-repeat',
    stretch: 'center/100% 100% no-repeat',
  };
  if (el.style.backgroundImage && el.style.backgroundImage !== 'none') {
    const url = el.style.backgroundImage;
    el.style.background = `${url} ${map[fit] || 'center/cover no-repeat'}`;
  }
}

function resetWallpaper() {
  applyWallpaperPreset('default');
  saveSettings('wallpaper_custom', null);
}

// ─── PERFIL ──────────────────────────────────────────────────

function loadProfileIntoSettings() {
  // Foto
  const photo = loadSetting('profile_photo', null);
  const preview = document.getElementById('profilePhotoPreview');
  if (photo) {
    preview.innerHTML = `<img src="${photo}" alt="Foto de perfil">`;
  } else {
    preview.innerHTML = WM.user ? WM.user.displayName[0].toUpperCase() : 'U';
  }
  // Nome
  const nameInput = document.getElementById('profileDisplayName');
  if (nameInput && WM.user) nameInput.value = WM.user.displayName || '';
}

function applyProfilePhoto(input) {
  const file = input.files[0];
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) { toast('Foto muito grande. Máx 5MB.', 'error'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    const url = e.target.result;
    saveSettings('profile_photo', url);
    _applyAvatarEverywhere(url);
    loadProfileIntoSettings();
    toast('Foto de perfil atualizada!', 'success', 1800);
  };
  reader.readAsDataURL(file);
}

function removeProfilePhoto() {
  saveSettings('profile_photo', null);
  _applyAvatarEverywhere(null);
  loadProfileIntoSettings();
  toast('Foto removida', 'info', 1800);
}

function _applyAvatarEverywhere(photoUrl) {
  const initial = WM.user ? WM.user.displayName[0].toUpperCase() : 'U';
  ['userAvatar', 'dropAvatar'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (photoUrl) {
      el.style.background = 'none';
      el.style.padding = '0';
      el.innerHTML = `<img src="${photoUrl}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" alt="Avatar">`;
    } else {
      el.style.background = '';
      el.style.padding = '';
      el.textContent = initial;
    }
  });
}

function saveProfile() {
  const name = document.getElementById('profileDisplayName').value.trim();
  if (!name) { toast('Nome não pode ser vazio', 'error'); return; }
  if (WM.user) {
    WM.user.displayName = name;
    saveSettings('profile_displayname', name);
    // Atualiza UI
    const dropName = document.getElementById('dropName');
    if (dropName) dropName.textContent = name;
    const greet = document.getElementById('greetingName');
    if (greet) greet.textContent = name.split(' ')[0];
  }
  toast('Perfil salvo!', 'success', 1800);
}

// ─── APARÊNCIA ────────────────────────────────────────────────

function buildThemePresets() {
  const current = loadSetting('color_theme', 'blue');
  document.getElementById('themePresets').innerHTML = COLOR_THEMES.map(t =>
    `<button class="theme-chip${t.id === current ? ' selected' : ''}"
             style="background:linear-gradient(135deg,${t.accent}22,${t.accent2}22);border-color:${t.accent}44;color:${t.accent}"
             onclick="applyColorTheme('${t.id}')">
       <span style="width:10px;height:10px;border-radius:50%;background:${t.accent};display:inline-block"></span>
       ${t.label}
     </button>`
  ).join('');
}

function applyColorTheme(id) {
  const theme = COLOR_THEMES.find(t => t.id === id);
  if (!theme) return;
  const root = document.documentElement;
  root.style.setProperty('--accent',  theme.accent);
  root.style.setProperty('--accent2', theme.accent2);
  saveSettings('color_theme', id);
  buildThemePresets();
  toast('Tema aplicado!', 'success', 1800);
}

function toggleEffect(type, val) {
  saveSettings('effect_' + type, val);
  if (type === 'particles') {
    const p = document.getElementById('particles');
    if (p) p.style.display = val ? '' : 'none';
  }
  if (type === 'blur') {
    document.body.classList.toggle('no-blur', !val);
    if (!document.getElementById('no-blur-style')) {
      const s = document.createElement('style');
      s.id = 'no-blur-style';
      s.textContent = '.no-blur *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important;}';
      document.head.appendChild(s);
    }
  }
  if (type === 'animations') {
    document.body.classList.toggle('no-animations', !val);
    if (!document.getElementById('no-anim-style')) {
      const s = document.createElement('style');
      s.id = 'no-anim-style';
      s.textContent = '.no-animations *{animation:none!important;transition:none!important;}';
      document.head.appendChild(s);
    }
  }
}

function applyWindowOpacity(val) {
  document.getElementById('windowOpacityVal').textContent = val + '%';
  document.documentElement.style.setProperty('--window-opacity', val / 100);
  saveSettings('window_opacity', val);
  // Aplica nas janelas existentes
  document.querySelectorAll('.app-window').forEach(w => {
    w.style.setProperty('--win-opacity', val / 100);
  });
}

// ─── SISTEMA ─────────────────────────────────────────────────

async function loadSystemInfo() {
  const grid = document.getElementById('sysinfoGrid');
  if (!grid) return;
  try {
    const res  = await fetch('/api/system');
    const data = await res.json();
    grid.innerHTML = `
      <div class="sysinfo-item"><div class="si-label">SO</div><div class="si-value">${data.os?.distro || data.os?.platform || '—'}</div></div>
      <div class="sysinfo-item"><div class="si-label">Hostname</div><div class="si-value">${data.os?.hostname || '—'}</div></div>
      <div class="sysinfo-item"><div class="si-label">CPU</div><div class="si-value">${data.cpu?.percent ?? '—'}% (${data.cpu?.cores ?? '?'} cores)</div></div>
      <div class="sysinfo-item"><div class="si-label">Memória</div><div class="si-value">${formatBytes(data.ram?.used)} / ${formatBytes(data.ram?.total)}</div></div>
      <div class="sysinfo-item"><div class="si-label">Disco</div><div class="si-value">${formatBytes(data.disk?.used)} / ${formatBytes(data.disk?.size)}</div></div>
      <div class="sysinfo-item"><div class="si-label">Uptime</div><div class="si-value">${formatUptime(data.os?.uptime || 0)}</div></div>
    `;
  } catch {
    grid.innerHTML = '<div class="sysinfo-loading">Erro ao carregar informações</div>';
  }
}

// ─── Restaurar configurações salvas ao iniciar ────────────────
function loadSettingsState() {
  // Wallpaper
  const customWp = loadSetting('wallpaper_custom', null);
  if (customWp) {
    _setWallpaperImage(customWp);
  } else {
    const wpId = loadSetting('wallpaper_id', 'default');
    if (wpId && wpId !== 'default') applyWallpaperPreset(wpId);
  }
  // Fit
  const fit = loadSetting('wallpaper_fit', 'cover');
  const fitEl = document.getElementById('wallpaperFit');
  if (fitEl) fitEl.value = fit;
  // Tema
  const theme = loadSetting('color_theme', 'blue');
  if (theme !== 'blue') applyColorTheme(theme);
  // Foto de perfil
  const photo = loadSetting('profile_photo', null);
  if (photo) _applyAvatarEverywhere(photo);
  // Efeitos
  const toggleIds = ['particles', 'blur', 'animations'];
  toggleIds.forEach(eff => {
    const val = loadSetting('effect_' + eff, true);
    const cb = document.getElementById('toggle' + eff.charAt(0).toUpperCase() + eff.slice(1));
    if (cb) cb.checked = val;
    if (!val) toggleEffect(eff, false);
  });
  // Opacidade janelas
  const opac = loadSetting('window_opacity', 95);
  const slider = document.getElementById('windowOpacity');
  if (slider) { slider.value = opac; applyWindowOpacity(opac); }
}
