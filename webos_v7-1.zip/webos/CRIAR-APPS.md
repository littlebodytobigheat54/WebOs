# 📦 Como criar apps para o WebOS

---

## Estrutura de um app

Todo app é um arquivo HTML simples. O sistema carrega ele dentro de um `<iframe>` na janela do desktop.

---

## Método 1 — App instalado direto (sempre disponível)

Crie uma pasta dentro de `/apps/` com dois arquivos:

```
apps/
└── meu-app/
    ├── meta.json        ← informações do app
    └── frontend.html    ← a interface do app
```

### meta.json
```json
{
  "id": "meu-app",
  "name": "Meu App",
  "icon": "🚀",
  "description": "Descrição curta do app",
  "version": "1.0.0",
  "system": false
}
```

> `"system": true` impede que o app seja desinstalado pela loja.

### frontend.html
Qualquer HTML/CSS/JS normal. Não precisa de backend — é só uma página.

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Meu App</title>
</head>
<body>
  <h1>Olá, WebOS!</h1>
</body>
</html>
```

**Pronto.** Reinicie o servidor e o app aparece no desktop.

---

## Método 2 — App na loja (usuário instala/desinstala)

Crie um arquivo `.json` em `/store/`:

```
store/
└── meu-app.json
```

### Estrutura do arquivo de loja
```json
{
  "id": "meu-app",
  "name": "Meu App",
  "icon": "🚀",
  "description": "Descrição do app",
  "version": "1.0.0",
  "category": "Utilitários",
  "author": "Seu Nome",
  "frontend": "<todo o conteúdo do frontend.html aqui como string>"
}
```

> O campo `"frontend"` é o HTML inteiro como uma string JSON.
> Use aspas duplas escapadas (`\"`) ou gere o JSON via script.

### Como gerar o JSON de loja facilmente (Python)
```python
import json

with open('meu-app.html', 'r') as f:
    html = f.read()

app = {
    "id": "meu-app",
    "name": "Meu App",
    "icon": "🚀",
    "description": "Descrição",
    "version": "1.0.0",
    "category": "Utilitários",
    "author": "Você",
    "frontend": html
}

with open('store/meu-app.json', 'w') as f:
    json.dump(app, f, ensure_ascii=False, indent=2)
```

---

## Comunicando com o backend (APIs disponíveis)

Dentro do app você pode chamar qualquer rota da API com `fetch()`:

```javascript
// Listar arquivos
const res  = await fetch('/api/files?path=/home');
const data = await res.json();

// Executar comando no terminal
const res = await fetch('/api/terminal/exec', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ cmd: 'ls -la', cwd: '/home' })
});

// Informações do sistema
const res  = await fetch('/api/system');
const info = await res.json();
// info.cpu.percent, info.ram.used, info.disk.free, info.os.hostname
```

### Rotas disponíveis
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/system` | CPU, RAM, disco, OS |
| GET | `/api/files?path=` | Listar diretório |
| GET | `/api/files/read?path=` | Ler arquivo de texto |
| POST | `/api/terminal/exec` | Executar comando `{cmd, cwd}` |
| GET | `/api/docker/containers` | Listar containers |
| POST | `/api/docker/start` | Iniciar container `{containerId}` |
| POST | `/api/docker/stop` | Parar container `{containerId}` |
| GET | `/api/user` | Dados do usuário logado |

---

## Dicas de estilo (para ficar consistente com o WebOS)

Copie estas variáveis CSS no seu app e use elas:

```css
:root {
  --bg: #050912;
  --surface: rgba(15, 20, 40, 0.95);
  --glass: rgba(255, 255, 255, 0.04);
  --border: rgba(99, 140, 255, 0.18);
  --accent: #4f7cff;
  --accent2: #06d6a0;
  --text: #dde8ff;
  --text-muted: #5a6a8a;
  --radius: 12px;
  --font: 'Outfit', sans-serif;
}
```

---

## Apps de exemplo incluídos na loja

| App | Arquivo | O que demonstra |
|-----|---------|-----------------|
| Calculadora | `store/calculadora.json` | UI pura, teclado |
| Relógio & Crono | `store/relogio.json` | Canvas/SVG, setInterval |
| Bloco de Notas | `store/notepad.json` | localStorage, salvar arquivo |

---

## Resumo rápido

```
Quer instalar sempre?     →  crie pasta em /apps/meu-app/
Quer distribuir na loja?  →  crie arquivo em /store/meu-app.json
Precisa de dados reais?   →  use fetch('/api/...')
```
